/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package precivilization;

/**
 *
 * @author bryantsahota
 */
public class Rates {
    int popIncreasePerTurn = 1;
    int culturePtsPerTurn = 1;
    //numWorkers getting food * 5;
    int foodGainedPerTurn = 0;
    int chanceInvasion;
}
